using System;
using System.IO;
using System.Text;
using Tao.OpenGl;
using Auxiliary.VectorMath;

namespace Auxiliary.Graphics
{
	public class ShaderProgram
	{
        #region Protected Fields

        protected int vertexShader;

        protected int fragmentShader;

        protected int program;

        protected string log;

        #endregion

        #region Constructor

        public ShaderProgram()
        {
            vertexShader = Gl.glCreateShader(Gl.GL_VERTEX_SHADER);
            fragmentShader = Gl.glCreateShader(Gl.GL_FRAGMENT_SHADER);

            program = Gl.glCreateProgram();
        }

        #endregion

        #region Private Methods

        private bool SetShaderFile(int shaderType, string[] fileNames)
        {
            log += "Opening shader source files\n";
            
            string[] lines = new string[fileNames.Length];

            for (int i = 0; i < fileNames.Length; i++)
            {
            	if (File.Exists(fileNames[i]))
	            {
            		StreamReader sr = new StreamReader(fileNames[i]);
	
	                lines[i] = sr.ReadToEnd();
	            }
	            else
	            {
	                log += "Error! Cannot find shader file\n";
	
	                return false;
	            }
            }
            
            return SetShaderSource(shaderType, lines);
        }

        private bool SetShaderSource(int shaderType, string[] lines)
        {
            int shader = vertexShader;

            if (Gl.GL_FRAGMENT_SHADER == shaderType)
            {
                shader = fragmentShader;
            }
            
            log += "Loading shader source code\n";

          	Gl.glShaderSource(shader, lines.Length, lines, null);
            
            log += "Compiling shader source code\n";

            Gl.glCompileShader(shader);

            int status = 0;

            unsafe
            {
            	Gl.glGetShaderiv(shader, Gl.GL_COMPILE_STATUS, new IntPtr(&status));
            }

            if (0 != status)
            {
                log += "Shader was compiled successfully\n";
            }
            else
            {
                log += "Error! Failed to compile shader\n";
            }

            log += "Loading compiler information string\n";

            int capacity = 0;

            unsafe
            {
            	Gl.glGetShaderiv(shader, Gl.GL_INFO_LOG_LENGTH, new IntPtr(&capacity));
            }

            StringBuilder info = new StringBuilder(capacity);

            unsafe
            {
            	Gl.glGetShaderInfoLog(shader, Int32.MaxValue, null, info);
            }

            if (0 == info.Length)
            {
                log += "Compiler information string is empty\n";
            }
            else
            {
                log += info;
            }
            
            if (0 == status)
            {
                log += "Error! Failed to load shader\n";

                return false;
            }
            
            log += "Attaching shader to program object\n";

            Gl.glAttachShader(program, shader);
            
            log += "Shader succesfully loaded\n";

            return true;
        }

        #endregion

        #region Public Methods
        
        #region Methods for managing shader and program objects

        public bool SetVertexShaderFile(string[] fileNames)
        {
            log += "****************************************************\n";
            log += "* Setting vertex shader                            *\n";
            log += "****************************************************\n";
            
            return SetShaderFile(Gl.GL_VERTEX_SHADER, fileNames);
        }

        public bool SetFragmentShaderFile(string[] fileNames)
        {
            log += "****************************************************\n";
            log += "* Setting fragment shader                          *\n";
            log += "****************************************************\n";
            
            return SetShaderFile(Gl.GL_FRAGMENT_SHADER, fileNames);
        }

        public bool SetVertexShaderSource(string[] lines)
        {
            log += "****************************************************\n";
            log += "* Setting vertex shader                            *\n";
            log += "****************************************************\n";

            return SetShaderSource(Gl.GL_VERTEX_SHADER, lines);
        }

        public bool SetFragmentShaderSource(string[] lines)
        {
            log += "****************************************************\n";
            log += "* Setting fragment shader                          *\n";
            log += "****************************************************\n";

            return SetShaderSource(Gl.GL_FRAGMENT_SHADER, lines);
        }

        public bool LinkProgram()
        {
            log += "****************************************************\n";
            log += "* Linking program object                           *\n";
            log += "****************************************************\n";
            
            Gl.glLinkProgram(program);

            int  status = 0;

            unsafe
            {
            	Gl.glGetProgramiv(program, Gl.GL_LINK_STATUS, new IntPtr(&status));
            }

            if (0 != status)
            {
                log += "Program was linked successfully\n";
            }
            else
            {
                log += "Error! Failed to link program\n";
            }
            
            log += "Loading linker information string\n";

            int capacity = 0;
            
            unsafe
            {
                Gl.glGetProgramiv(program, Gl.GL_INFO_LOG_LENGTH, new IntPtr(&capacity));
            }

            StringBuilder info = new StringBuilder(capacity);

            unsafe
            {
                Gl.glGetProgramInfoLog(program, Int32.MaxValue, null, info);
            }

            if (0 == info.Length)
            {
                log += "Linker information string is empty\n";
            }
            else
            {
                log += info;
            }

            if (0 == status)
            {
                log += "Error! Failed to link program\n";

                return false;
            }

            return true;
        }

        public void Destroy()
        {
            unsafe
            {
                Gl.glDeleteShader(vertexShader);
                Gl.glDeleteShader(fragmentShader);

                Gl.glDeleteProgram(program);
            }
        }

        public void Bind()
        {
            Gl.glUseProgram(program);
        }

        public void Unbind()
        {
            Gl.glUseProgram(0);
        }

        #endregion
        
        #region Methods for input shader data
        
        public int GetUniformLocation(string name)
        {
            return Gl.glGetUniformLocation(program, name);
        }

        public Vector4D GetUniformVector(string name)
        {
            float[] values = new float[4];

            int location = Gl.glGetUniformLocation(program, name);

            if (location < 0)
                return Vector4D.Zero;

            Gl.glGetUniformfv(program, location, values);

            return new Vector4D(values);
        }

        public Vector4D GetUniformVector(int location)
        {
            float[] values = new float[4];

            Gl.glGetUniformfv(program, location, values);

            return new Vector4D(values);
        }

        public bool SetUniformInteger(string name, int value)
        {
            int location = Gl.glGetUniformLocation(program, name);

            if (location < 0)
                return false;

            Gl.glUniform1i(location, value);

            return true;
        }

        public bool SetUniformInteger(int location, int value)
        {
            Gl.glUniform1i(location, value);

            return true;
        }

        public bool SetUniformFloat(string name, float value)
        {
            int location = Gl.glGetUniformLocation(program, name);

            if (location < 0)
                return false;

            Gl.glUniform1f(location, value);

            return true;
        }

        public bool SetUniformFloat(int location, float value)
        {
            Gl.glUniform1f(location, value);

            return true;
        }

        public bool SetUniformVector(string name, Vector2D value)
        {
            int location = Gl.glGetUniformLocation(program, name);

            if (location < 0)
                return false;

            Gl.glUniform2fv(location, 1, value.ToArray());

            return true;
        }

        public bool SetUniformVector(int location, Vector2D value)
        {
            Gl.glUniform2fv(location, 1, value.ToArray());

            return true;
        }

        public bool SetUniformVector(string name, Vector3D value)
        {
            int location = Gl.glGetUniformLocation(program, name);

            if (location < 0)
                return false;

            Gl.glUniform3fv(location, 1, value.ToArray());

            return true;
        }

        public bool SetUniformVector(int location, Vector3D value)
        {
            Gl.glUniform3fv(location, 1, value.ToArray());

            return true;
        }

        public bool SetUniformVector(string name, Vector4D value)
        {
            int location = Gl.glGetUniformLocation(program, name);

            if (location < 0)
                return false;

            Gl.glUniform4fv(location, 1, value.ToArray());

            return true;
        }

        public bool SetUniformVector(int location, Vector4D value)
        {
            Gl.glUniform4fv(location, 1, value.ToArray());

            return true;
        }

        public bool SetUniformMatrix(string name, Matrix2D value)
        {
            int location = Gl.glGetUniformLocation(program, name);

            if (location < 0)
                return false;

            Gl.glUniformMatrix2fv(location, 1, Gl.GL_TRUE, value.ToArray());

            return true;
        }

        public bool SetUniformMatrix(int location, Matrix2D value)
        {
            Gl.glUniformMatrix2fv(location, 1, Gl.GL_TRUE, value.ToArray());

            return true;
        }
        
        public bool SetUniformMatrix(string name, Matrix3D value)
        {
            int location = Gl.glGetUniformLocation(program, name);

            if (location < 0)
                return false;

            Gl.glUniformMatrix3fv(location, 1, Gl.GL_TRUE, value.ToArray());

            return true;
        }

        public bool SetUniformMatrix(int location, Matrix3D value)
        {
            Gl.glUniformMatrix3fv(location, 1, Gl.GL_TRUE, value.ToArray());

            return true;
        }
        
        public bool SetUniformMatrix(string name, Matrix4D value)
        {
            int location = Gl.glGetUniformLocation(program, name);

            if (location < 0)
                return false;

            Gl.glUniformMatrix4fv(location, 1, Gl.GL_TRUE, value.ToArray());

            return true;
        }

        public bool SetUniformMatrix(int location, Matrix4D value)
        {
            Gl.glUniformMatrix4fv(location, 1, Gl.GL_TRUE, value.ToArray());

            return true;
        }

        public bool SetTexture(string name, int unit)
        {
            int location = Gl.glGetUniformLocation(program, name);

            if (location < 0)
                return false;

            Gl.glUniform1i(location, unit);

            return true;
        }

        public bool SetTexture(int location, int unit)
        {
            Gl.glUniform1i(location, unit);

            return true;
        }

        public bool SetAttributeName(int index, string name)
        {
            Gl.glBindAttribLocation(program, index, name);

            return true;
        }

        public int GetAttributeIndex(string name)
        {
            return Gl.glGetAttribLocation(program, name);
        }
        
        public Vector4D GetAttributeVector(string name)
        {
            int index = Gl.glGetAttribLocation(program, name);

            if (index < 0)
                return Vector4D.Zero;

            float[] values = new float[4];

            Gl.glGetVertexAttribfv(index, Gl.GL_CURRENT_VERTEX_ATTRIB, values);

            return new Vector4D(values);
        }
        
        public bool SetAttributeFloat(string name, float value)
        {
            int index = Gl.glGetAttribLocation(program, name);

            if (index < 0)
                return false;

            Gl.glVertexAttrib1f(index, value);

            return true;
        }

        public bool SetAttributeFloat(int index, float value)
        {
            Gl.glVertexAttrib1f(index, value);

            return true;
        }
        
        public bool SetAttributeVector(string name, Vector2D value)
        {
            int index = Gl.glGetAttribLocation(program, name);

            if (index < 0)
                return false;

            Gl.glVertexAttrib2fv(index, value.ToArray());

            return true;
        }

        public bool SetAttributeVector(int index, Vector2D value)
        {
            Gl.glVertexAttrib2fv(index, value.ToArray());

            return true;
        }
      
        public bool SetAttributeVector(string name, Vector3D value)
        {
            int index = Gl.glGetAttribLocation(program, name);

            if (index < 0)
                return false;

            Gl.glVertexAttrib3fv(index, value.ToArray());

            return true;
        }

        public bool SetAttributeVector(int index, Vector3D value)
        {
            Gl.glVertexAttrib3fv(index, value.ToArray());

            return true;
        }
        
        public bool SetAttributeVector(string name, Vector4D value)
        {
            int index = Gl.glGetAttribLocation(program, name);

            if (index < 0)
                return false;

            Gl.glVertexAttrib4fv(index, value.ToArray());

            return true;
        }

        public bool SetAttributeVector(int index, Vector4D value)
        {
            Gl.glVertexAttrib4fv(index, value.ToArray());

            return true;
        }        
        
        #endregion

        #endregion

        #region Properties

        public string Log
        {
            get
            {
                return log;
            }
        }

        public int VertexShaderHandle
        {
            get
            {
                return vertexShader;
            }
        }

        public int FragmentShaderHandle
        {
            get
            {
                return fragmentShader;
            }
        }

        public int ProgramHandle
        {
            get
            {
                return program;
            }
        }

        #endregion
	}
}

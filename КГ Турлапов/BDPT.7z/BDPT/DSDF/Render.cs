﻿using System;
using System.Collections.Generic;
using Auxiliary.VectorMath;

namespace DSDF
{
    public class Render
    {
        private const int countRayPerPixel = 1;
        private const int MaxDepth = 8; //максимальное количество отражений для луча // 25
        private const float CoeffAttenuationRay = 0.9f;
        private readonly Vector3D eye; //камера
        private readonly Scene scene; //сцена

        public Render(Scene scene)
        {
            this.scene = scene;
            eye = new Vector3D(256, 256, 1228);
        }

        public Vector3D PathTrace(Ray ray, int depth, Vector3D color)
        {
            if (Vector3D.Dot(color, color) < 0.001)
            {
                //луч затух
                return Vector3D.Zero;
            }
            if (depth == MaxDepth)
            {
                //достигли максимального количества отражений луча
                return Vector3D.Zero;
            }
            Hit hit = scene.hit(ray);
            if (hit.Distance >= 1000000 || hit.Distance < 0)
            {
                //пересечений нет
                return Vector3D.Zero;
            }
            BSDF m = hit.Material;
            if (m.Emission != Vector3D.Zero)
            {
                //пересечение с источником света
                return m.Emission;
            }

            Vector3D newColor = Vector3D.Zero;
            Vector3D newDirection = m.sample(ray.Direct, hit.Normal, color, ref newColor);
            newColor = newColor * CoeffAttenuationRay;
            var newRay = new Ray(hit.Point, newDirection);

            return newColor * PathTrace(newRay, depth + 1, newColor);
        }

        private bool IsVisibleTwoPoint(Vector3D pointA, Vector3D pointB)
        {
            var ray = new Ray(pointA, pointB - pointA);
            Hit hit = scene.hit(ray);
            if (!ReferenceEquals(hit.Point, null) && hit.Point == pointB)
            {
                return true;
            }
            return false;
        }

        private Vector3D GetColorForIJ(PointOfRayTrace pointI, PointOfRayTrace pointJ)
        {
            if (IsVisibleTwoPoint(pointI.Point, pointJ.Point))
            {
                return pointI.Color * pointJ.Color;
            }
            return Vector3D.Zero;
        }

        private bool BuildPath(Ray ray, IList<PointOfRayTrace> listPoint, Vector3D color, int depth)
        {
            PointOfRayTrace point;

            if (Vector3D.Dot(color, color) < 0.0000001)
            {
                //луч затух
                return false;
            }
            if (depth == MaxDepth)
            {
                //достигли максимального количества отражений луча
                return false;
            }
            Hit hit = scene.hit(ray);
            if (hit.Distance >= 1000000 || hit.Distance < 0)
            {
                //пересечений нет
                return false;
            }
            BSDF m = hit.Material;
            if (m.Emission != Vector3D.Zero)
            {
                //пересечение с источником света
                var tmp = new Vector3D(1, 1, 1);
                if (listPoint.Count != 0)
                {
                    tmp = listPoint[listPoint.Count - 1].Color;
                }

                point = new PointOfRayTrace(hit.Point, tmp);
                listPoint.Add(point);
                return true;
            }

            Vector3D newColor = Vector3D.Zero;
            Vector3D newDirection = m.sample(ray.Direct, hit.Normal, color, ref newColor);
            newColor = newColor * CoeffAttenuationRay;
            var newRay = new Ray(hit.Point, newDirection);

            point = new PointOfRayTrace(hit.Point, newColor);
            listPoint.Add(point);

            return BuildPath(newRay, listPoint, newColor, depth + 1);
        }

        public Vector3D MapSampleToCosineDistribution(float r1, float r2)
        {
            var sin_phi = (float) Math.Sin(2 * r1 * Math.PI);
            var cos_phi = (float) Math.Cos(2 * r1 * Math.PI);

            var cos_theta = (float) Math.Pow(1 - r2, 0.5);
            var sin_theta = (float) Math.Sqrt(1 - cos_theta * cos_theta);

            float x = sin_theta * cos_phi;
            float y = sin_theta * sin_phi;
            float z = cos_theta;

            return new Vector3D(x, y, z);
        }

        public Ray GenerateLightRay()
        {
            float r1 = Global.GetRndFloat();
            float r2 = Global.GetRndFloat();
            Vector3D direction = MapSampleToCosineDistribution(r1, r2);
            direction.Y *= -1;
            r1 = Global.GetRndFloat();
            r2 = Global.GetRndFloat();
            float r3 = Global.GetRndFloat();
            float r4 = Global.GetRndFloat();
            if (r3 < 0.5f)
            {
                r1 *= -1;
            }
            if (r4 < 0.5f)
            {
                r2 *= -1;
            }
            var point = new Vector3D(scene.Light.Center.X + (r1 * scene.Light.SizeX) / 2,
                                     scene.Light.Center.Y - 0.0001f,
                                     scene.Light.Center.Z + (r1 * scene.Light.SizeZ) / 2);

            var ray = new Ray(point, direction);
            return ray;
        }

        public Vector3D BiDirectionalPathTracing(Ray ray, int depth, Vector3D Color)
        {
            var list_point_eye = new List<PointOfRayTrace>();
            var list_point_light = new List<PointOfRayTrace>();

            Vector3D resColor = Vector3D.Zero;
            if (BuildPath(ray, list_point_eye, Color, 0))
            {
                //path racing достиг источника
                resColor = list_point_eye[list_point_eye.Count - 1].Color;
                return resColor;
            }

            Ray lightRay = GenerateLightRay();

            BuildPath(lightRay, list_point_light, Color, 0);

            int tmp = 0;
            if (resColor != Vector3D.Zero)
            {
                tmp = 1;
            }
            for (int i = (list_point_eye.Count - 1 - tmp); i >= 0; i--)
            {
                for (int j = (list_point_light.Count - 1); j >= 0; j--)
                {
                    resColor += GetColorForIJ(list_point_eye[i], list_point_light[j]);
                }
            }
            return resColor;
        }

        public void FillImage(float[] image, int k, float lightning)
        {
            for (int i = 0; i < 512; i++)
            {
                for (int j = 0; j < 512; j++)
                {
                    for (int q = 0; q < countRayPerPixel; q++)
                    {
                        //создаем луч
                        var ray = new Ray();
                        ray.Origin = eye;
                        ray.Direct = new Vector3D(j + Global.GetRndFloat(), i + Global.GetRndFloat(), 0) - eye;
                        ray.Direct = Vector3D.Normalize(ray.Direct);

                        var color = new Vector3D(lightning, lightning, lightning);

                        //color = PathTrace(ray, 0, color);
                        color = BiDirectionalPathTracing(ray, 0, color);

                        if (k == 0)
                        {
                            image[(i * 512 + j) * 3] = color.X;
                            image[(i * 512 + j) * 3 + 1] = color.Y;
                            image[(i * 512 + j) * 3 + 2] = color.Z;
                        }
                        else
                        {
                            image[(i * 512 + j) * 3] = ((k * image[(i * 512 + j) * 3] / (k + 1)) + color.X / (k + 1));
                            image[(i * 512 + j) * 3 + 1] = ((k * image[(i * 512 + j) * 3 + 1] / (k + 1)) +
                                                            color.Y / (k + 1));
                            image[(i * 512 + j) * 3 + 2] = ((k * image[(i * 512 + j) * 3 + 2] / (k + 1)) +
                                                            color.Z / (k + 1));
                        }
                    }
                }
            }
        }

        public class PointOfRayTrace
        {
            public Vector3D Color;
            public Vector3D Point;

            public PointOfRayTrace(Vector3D Point, Vector3D Color)
            {
                this.Point = Point;
                this.Color = Color;
            }
        }
    }
}
using System;
using System.Windows.Forms;
using Auxiliary.VectorMath;

namespace Auxiliary.Graphics
{
	public class Mouse
	{
		#region Private Fields
			
		private int x;         
		
		private int y;        
		
		private int deltaX;      
		
		private int deltaY;
		
		#endregion
			
		#region Public Fields
		
		public float Speed = 0.25f;
		
		public float AngleX = 210.0f;
		
		public float AngleY = 30.0f;
		
		public float Depth = -30.0f;
		
		#endregion

		#region Constructor
		
		public Mouse() { }
		
		public Mouse(float angleX, float angleY)
		{
			AngleX = angleX;
			AngleY = angleY;
		}
		
		#endregion
		
		#region Public Methods

		public void OnMouseDown(MouseEventArgs e)
		{
			x = e.X;
			y = e.Y;
		}
		
		public void OnMouseMove(MouseEventArgs e)
		{		
			deltaX = e.X - x;
			deltaY = e.Y - y;
			        	
			x = e.X;
			y = e.Y;
			
			if (e.Button == MouseButtons.Left)
			{			
				if (deltaX != 0)
				{
					AngleY += deltaX * Speed;
				}
				
				if (deltaY != 0)
				{
					AngleX += deltaY * Speed;
				}
			}
			else
				if (e.Button == MouseButtons.Right)
				{
					if (deltaY != 0)
					{
						Depth -= deltaY * Speed;
					}
				}
		}
		
		#endregion
	}
}

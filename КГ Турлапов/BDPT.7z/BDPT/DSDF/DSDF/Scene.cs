﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Auxiliary.VectorMath;
using System.Collections;

namespace DSDF
{
    public static class Global
    {
        static Random Rnd = new Random();
        public static float GetRndFloat()
        {
            return (float)Rnd.NextDouble();
        }

        public static Vector3D UnitX = new Vector3D(1, 0, 0);
        public static Vector3D UnitY = new Vector3D(0, 1, 0);
        public static Vector3D UnitZ = new Vector3D(0, 0, 1);
    }

    public struct Ray
    {
        /*! Starting point of the ray. */
        public Vector3D Origin;

        /*! Direction vector of the the ray. */
        public Vector3D Direct;

        /*! Creates new ray. */
        public Ray(Vector3D origin, Vector3D direct)
        {
            Origin = origin;
            Direct = direct;
        }

        public Vector3D at(float time)
        {
            return Origin + Direct * time;
        }

        public void move(float time)
        {
            Origin = at(time);
        }
    }

    /*!
    * Data structure for storing BSDF.
    */
    public struct BSDF
    {
        /*! Weight of the diffuse BRDF. */
        public Vector3D Kd;

        /*! Weight of the specular BRDF. */
        public Vector3D Ks;

        /*! Weight of the transmission BTDF. */
        public Vector3D Kt;

        /*! Material emission. */
        public Vector3D Emission;

        /*! Creates new surface BSDF. */
        public BSDF(Vector3D kd,
                    Vector3D ks,
                    Vector3D kt)
        {
            Kd = kd;
            Ks = ks;
            Kt = kt;
            Emission = Vector3D.Zero;
        }

        /*! Creates new surface BSDF. */
        public BSDF(Vector3D emission)
        {
            Kd = Vector3D.Zero;
            Ks = Vector3D.Zero;
            Kt = Vector3D.Zero;
            Emission = emission;
        }

        /*! Samples BSDF. */
        public void sample(Vector3D output,
                            Vector3D factor,
                            Vector3D input,
                            Vector3D normal)
        {

        }
    };


    /*!
    * Describes local space at the hit point (visualization space).
    */
    public struct LocalSpace
    {
        /*! Local X axis. */
        public Vector3D AxisX;

        /*! Local Y axis. */
        public Vector3D AxisY;

        /*! Local Z axis. */
        public Vector3D AxisZ;

        /*! Creates new local space. */
        public LocalSpace(Vector3D axisX,
                            Vector3D axisY,
                            Vector3D axisZ)
        {
            AxisX = axisX;
            AxisY = axisY;
            AxisZ = axisZ;
        }

        /*! Creates new local space. */
        public LocalSpace(Vector3D normal)
        {
            AxisZ = normal;


            AxisX = Vector3D.Cross(new Vector3D(0, 1, 0), normal);
            AxisY = Vector3D.Cross(new Vector3D(1, 0, 0), normal);

            float xLength = Vector3D.Length(AxisX),
                  yLength = Vector3D.Length(AxisY);

            if (xLength > yLength)
            {
                AxisX = AxisX / xLength;
                AxisY = Vector3D.Cross(AxisX, normal);
            }
            else
            {
                AxisY = AxisY / yLength;
                AxisX = Vector3D.Cross(AxisY, normal);
            }
        }

        /*! Transforms specified vector to local space from world space. */
        public Vector3D to(Vector3D vector)
        {
            return new Vector3D(Vector3D.Dot(vector, AxisX),
                                Vector3D.Dot(vector, AxisY),
                                Vector3D.Dot(vector, AxisZ));

        }

        /*! Transforms specified vector from local space to world space. */
        public Vector3D from(Vector3D vector)
        {
            return vector.X * AxisX + vector.Y * AxisY + vector.Z * AxisZ;
        }
    };

    abstract public class Geometry
    {
        /*! Material of the sphere. */
        public BSDF Material;

        /*! Creates new sphere. */
        public Geometry(BSDF material)
        {
            Material = material;
        }

        /*! Intersects ray with scene object. */
        public abstract float hit(Ray ray);

        /*! Computes normal to the scene object. */
        public abstract Vector3D normal(Vector3D point);
    };

    /*! Sphere object. */
    public class Sphere : Geometry
    {
        /*! Center of the sphere. */
        public Vector3D Center;

        /*! Sphere radius. */
        public float Radius;

        /*! Creates new sphere. */
        public Sphere(Vector3D center, float radius, BSDF material)
            : base(material)
        {
            Center = center;
            Radius = radius;
        }

        /*! Intersects ray with sphere object. */
        public override float hit(Ray ray)
        {
            Vector3D origin = ray.Origin - Center, direct = ray.Direct;

            double A = Vector3D.Dot(direct, direct),
                  B = Vector3D.Dot(direct, origin),
                  C = Vector3D.Dot(origin, origin);

            double D = B * B - A * (C - Radius * Radius);

            if (D > 0)
            {
                D = Math.Sqrt(D);

                C = (-B - D) / A;
                D = (-B + D) / A;

                if (D >= 0)
                {
                    return C >= 0 ? (float)C : (float)D;
                }
            }

            return -1;
        }

        /*! Computes normal to the sphere object. */
        public override Vector3D normal(Vector3D point)
        {
            return Vector3D.Normalize(point - Center);
        }
    }

    /*! Plane object. */
    public class Plane : Geometry
    {
        /*! Normal to the plane. */
        public Vector3D Normal;

        /*! Minimum cut point of the plane. */
        public Vector3D Minimum;

        /*! Maximum cut point of the plane. */
        public Vector3D Maximum;

        /*! Translation of the plane. */
        public float Translation;

        /*! Creates new plane. */
        public Plane(Vector3D normal,
                Vector3D minimum,
                Vector3D maximum,
               float translation,
               BSDF material)
            : base(material)
        {
            Normal = normal;
            Minimum = minimum;
            Maximum = maximum;
            Translation = translation;
        }

        /*! Intersects ray with plane object. */
        public override float hit(Ray ray)
        {
            float time = (Translation - Vector3D.Dot(Normal, ray.Origin)) / Vector3D.Dot(Normal, ray.Direct);

            Vector3D point = ray.at(time);

            bool outside = (point.X < Minimum.X - 1E-5 || point.X > Maximum.X + 1E-5) ||
                           (point.Y < Minimum.Y - 1E-5 || point.Y > Maximum.Y + 1E-5) ||
                           (point.Z < Minimum.Z - 1E-5 || point.Z > Maximum.Z + 1E-5);

            return outside ? -1 : time;
        }


        public override Vector3D normal(Vector3D point)
        {
            return Normal;
        }
    }

    /*!
     * Data structure for storing information about the hit point.
     */
    public struct Hit
    {
        /*! Object material. */
        public BSDF Material;

        /*! Distance to hit point. */
        public float Distance;

        /*! Hit point. */
        public Vector3D Point;

        /*! Normal at hit point. */
        public Vector3D Normal;

        /*! Creates new hit information. */
        public Hit(float distance)
        {
            Distance = distance;
            Material = new BSDF();
            Normal = null;
            Point = null;
        }

        /*! Creates new hit information. */
        public Hit(BSDF material, float distance)
        {
            Material = material;
            Distance = distance;
            Normal = null;
            Point = null;
        }
    }

    /*! Computer scene. */
    public class Scene
    {
        /*! Object list. */
        public List<Geometry> Objects = new System.Collections.Generic.List<Geometry>();

        /*! Light source. */
        public Source Light;

        /*! Checks visibility. */
        public float visibility(Ray ray, float time)
        {
            if (time <= 0)
                return 1.0f;   // слишком маленькое расстояние

            for (int i = 0; i < Objects.Count; ++i)
            {
                float test = Objects[i].hit(ray);

                if (test > 0 && test < time)
                    return 0.0f;
            }

            float test1 = 1000000;

            if (Light.intersect(ray, test1))
            {
                if (test1 < time)
                    return 0.0f;
            }

            return 1.0f;
        }


        public Hit hit(Ray ray)
        {
            Hit hit = new Hit(1000000);

            Geometry obj = null;

            for (int i = 0; i < Objects.Count; ++i)
            {
                float test = Objects[i].hit(ray);

                if (test > 0 && test < hit.Distance)
                {
                    obj = Objects[i];

                    hit = new Hit(obj.Material, test);
                }
            }

            if (System.Object.ReferenceEquals(obj, null))
            {
                hit.Distance = -1;
            }
            else if (hit.Distance<10000)
            {
                hit.Point = ray.at(hit.Distance);

                hit.Normal = obj.normal(hit.Point);
            }

            float test1 = 100;

            if (Light.intersect(ray, test1))
            {
                if (hit.Distance < 0 || test1 < hit.Distance)
                    hit =new Hit(Light.Material, test1);

                hit.Point = ray.at(hit.Distance);

                hit.Normal = Light.normal();
            }

            return hit;
        }
    }

    /*!
    * Data structure for storing light source.
     */
    public struct Source
    {
        /*! Emitted radiance. */
        public BSDF Material;

        /*! Center of rectangle light source. */
        public Vector3D Center;

        /*! Length of rectangle light source in X direction. */
        public float SizeX;

        /*! Length of rectangle light source in Z direction. */
        public float SizeZ;

        /*! Creates new rectangle light source. */
        public Source(Vector3D radiance,
                Vector3D center,
                float sizeX,
                float sizeZ)
        {
            Normal = new Vector3D(0, -1, 0);
            Center = center;
            SizeX = sizeX;
            SizeZ = sizeZ;
            Material = new BSDF(radiance);
        }

        public Vector3D normal()
        {
            return Normal;
        }

        /*! Computes sampled point and emitted radiance for diffuse rectangle light. */
        public void sample(Vector3D point)
        {
            /* Compute sampled point on rectangle light source */

            float ksi1 = Global.GetRndFloat() - 0.5f,
                  ksi2 = Global.GetRndFloat() - 0.5f;

            point = Center + SizeX * new Vector3D(1, 0, 0) * ksi1 + SizeZ * new Vector3D(0, 0, 1) * ksi2;
        }

        /*! Computes the intersection of specified ray with diffuse rectangle light. */
        public bool intersect(Ray ray,
                       float distance,
                       Vector3D radiance = null)
        {
            /* Transform ray to local space */

            Vector3D origin = ray.Origin - Center, direct = ray.Direct;

            origin = new Vector3D(Vector3D.Dot(Global.UnitX, origin), Vector3D.Dot(Normal, origin), Vector3D.Dot(Global.UnitZ, origin));

            direct = new Vector3D(Vector3D.Dot(Global.UnitX, direct), Vector3D.Dot(Normal, direct), Vector3D.Dot(Global.UnitZ, direct));

            /* Compute intersection point */

            distance = -origin.Y / direct.Y;

            bool outside = Math.Abs(origin.X + direct.X * distance) > SizeX / 2.0f ||
                           Math.Abs(origin.Z + direct.Z * distance) > SizeZ / 2.0f;


            /* Compute emitted radiance */

            if (!System.Object.ReferenceEquals(radiance, null))
            {
                radiance = Vector3D.Dot(Normal, ray.Direct) < 0 ? Material.Emission : Vector3D.Zero;
            }
            return distance >= 0 && !outside;
        }

        /*! Computes sampled radiance along an arbitrary ray from diffuse rectangle light. */
        public void sample(Vector3D origin,
                    Vector3D direct,
                    Vector3D normal)
        {
            /* Compute sampled ray from the light source */

            float ksi1 = Global.GetRndFloat() - 0.5f,
                  ksi2 = Global.GetRndFloat() - 0.5f;

            origin = Center + SizeX * Global.UnitX * ksi1 + SizeZ * Global.UnitZ * ksi2;

            ksi1 = Global.GetRndFloat();
            ksi2 = Global.GetRndFloat();

            // direct = uniformSampleSphere( ksi1, ksi2 );

            if (Vector3D.Dot(direct, normal = Normal) < 0)
            {
                direct = -direct;
            }
        }

        /*! Returns light source area. */
        public float area()
        {
            return SizeX * SizeZ;
        }

        /*! Normal to the light source. */
        private Vector3D Normal;
    };
}

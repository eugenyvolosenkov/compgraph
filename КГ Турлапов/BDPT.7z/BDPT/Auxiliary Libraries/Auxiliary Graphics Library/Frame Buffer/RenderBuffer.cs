using System;
using Tao.OpenGl;

namespace Auxiliary.Graphics
{
	public class RenderBuffer
	{
		#region Private Fields
			
		private int handle;
				
		#endregion
		
		#region Public Fields
		
		public int Width;
		
		public int Height;
		
		public int Target = Gl.GL_RENDERBUFFER_EXT;
				
		public int InternalFormat = Gl.GL_DEPTH_COMPONENT16_ARB;
		
		public int Attachment = Gl.GL_DEPTH_ATTACHMENT_EXT;
		
		#endregion
		
		#region Constructor
		
		public RenderBuffer(int width, int height)
		{
			Width = width;
			Height = height;
			
		    unsafe
		    {
		    	fixed (int* pointer = &handle)
		    	{
		    		Gl.glGenRenderbuffersEXT(1, new IntPtr(pointer));
		    	}
		    }
		}
		
		public RenderBuffer(int width, int height, int target, int internalFormat, int attachment)
			: this(width, height)
		{
			Target = target;
			InternalFormat = internalFormat;
			Attachment = attachment;
		}
		
		#endregion
		
		#region Public Methods
			
		public void Create()
		{	
			Gl.glBindRenderbufferEXT(Gl.GL_RENDERBUFFER_EXT, handle);
			Gl.glRenderbufferStorageEXT(Target, InternalFormat, Width, Height);	
		}
		
		public void Destroy()
		{
		    unsafe
		    {
		    	fixed (int* pointer = &handle)
		    	{
		    		Gl.glDeleteRenderbuffersEXT(1, new IntPtr(pointer));
		    	}
		    }
		}
				
		#endregion
		
		#region Properties
				
		public int Handle
		{
			get
			{
				return handle;
			}
		}
		
		#endregion
	}
}

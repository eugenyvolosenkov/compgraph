using System;
using System.Collections;
using Tao.OpenGl;

namespace Auxiliary.Graphics
{
	public class Framebuffer
	{
		#region Private Fields
				
		private int handle;
		
		#endregion
		
		#region Construtor and Destructor
		
		public Framebuffer()
		{
			unsafe
			{
				fixed (int* pointer = &handle)
				{
					Gl.glGenFramebuffersEXT(1, new IntPtr(pointer));
				}
			}
		}
				
		#endregion
		
		#region Private Methods
				
		private bool SetRenderBuffer(int target, int attachment, int renbufId)
		{
			if (handle == 0)
			{
				return false;
			}

            int currentBuffer = 0;

            unsafe
            {
            	Gl.glGetIntegerv(Gl.GL_FRAMEBUFFER_BINDING_EXT, new IntPtr(&currentBuffer));
            }

            if (currentBuffer != handle)
            {
                Gl.glBindFramebufferEXT(Gl.GL_FRAMEBUFFER_EXT, handle);
            }
				
            {           	
            	Gl.glBindRenderbufferEXT(target, renbufId);
            	
				Gl.glFramebufferRenderbufferEXT(Gl.GL_FRAMEBUFFER_EXT,  attachment,
		                               target, renbufId);
            }
           
            if (currentBuffer != handle)
            {
                Gl.glBindFramebufferEXT(Gl.GL_FRAMEBUFFER_EXT, currentBuffer);
            }
            
			return true;			
		}
		
		private bool SetTexture(int target, int texId)
		{
			if (handle == 0)
			{
				return false;
			}

            int currentBuffer = 0;

            unsafe
            {
            	Gl.glGetIntegerv(Gl.GL_FRAMEBUFFER_BINDING_EXT, new IntPtr(&currentBuffer));
            }

            if (currentBuffer != handle)
            {
                Gl.glBindFramebufferEXT(Gl.GL_FRAMEBUFFER_EXT, handle);
            }
				
            {           	
            	Gl.glBindTexture(target, handle);
				Gl.glFramebufferTexture2DEXT(Gl.GL_FRAMEBUFFER_EXT,
            	                             Gl.GL_COLOR_ATTACHMENT0_EXT,
            	                             target, texId, 0);
            }
           
            if (currentBuffer != handle)
            {
                Gl.glBindFramebufferEXT(Gl.GL_FRAMEBUFFER_EXT, currentBuffer);
            }
            
			return true;
		}	
		
		#endregion
		
		#region Public Methods
			
		public void Destroy()
		{
			unsafe
			{
				fixed (int* pointer = &handle)
				{
					Gl.glDeleteFramebuffersEXT(1, new IntPtr(pointer));
				}
			}
		}
		
		public bool Bind()
		{		
			Gl.glBindFramebufferEXT(Gl.GL_FRAMEBUFFER_EXT, handle);

			
			Gl.glDrawBuffer(Gl.GL_COLOR_ATTACHMENT0_EXT);
			Gl.glReadBuffer(Gl.GL_COLOR_ATTACHMENT0_EXT);
			
			return true;
		}
		
		public bool	Unbind()
		{		
			Gl.glBindFramebufferEXT(Gl.GL_FRAMEBUFFER_EXT, 0);
			
			Gl.glDrawBuffer(Gl.GL_BACK);
			Gl.glReadBuffer(Gl.GL_BACK);
		
			return true;
		}
		
		public bool	AttachTexture(Texture2D texture)
		{			
			return SetTexture(Texture2D.Target, texture.Handle);
		}	
	
		public bool DetachTexture(Texture2D texture)
		{			
			return SetTexture(Texture2D.Target, 0);
		}
		
		public bool	AttachRenderBuffer(RenderBuffer renbuf)
		{			
			return SetRenderBuffer(renbuf.Target, renbuf.Attachment, renbuf.Handle);
		}	
	
		public bool DetachRenderBuffer(RenderBuffer renbuf)
		{			
			return SetRenderBuffer(renbuf.Target, Gl.GL_DEPTH_ATTACHMENT_EXT, 0);
		}
					
		#endregion
		
		#region Properties
		
		public bool	Ready
		{
			get
			{
				int	currentBuffer = 0;
				
				unsafe
				{
					Gl.glGetIntegerv(Gl.GL_FRAMEBUFFER_BINDING_EXT, new IntPtr(&currentBuffer));
				}

				if (currentBuffer != handle)
				{
					Gl.glBindFramebufferEXT(Gl.GL_FRAMEBUFFER_EXT, handle);
					Gl.glReadBuffer(Gl.GL_COLOR_ATTACHMENT0_EXT);
				}

				int status = Gl.glCheckFramebufferStatusEXT(Gl.GL_FRAMEBUFFER_EXT);

				if (currentBuffer != handle)
				{
					Gl.glBindFramebufferEXT (Gl.GL_FRAMEBUFFER_EXT, currentBuffer);
				}

				return status == Gl.GL_FRAMEBUFFER_COMPLETE_EXT;
			}
		}
		
		public static int MaxAttachemnts
		{
			get
			{
			    int max = 0;
			
			    unsafe
			    {
			    	Gl.glGetIntegerv(Gl.GL_MAX_COLOR_ATTACHMENTS_EXT, new IntPtr(&max));
			    }
			    
				return max;
			}
		}
		
		public static int MaxSize
		{
			get
			{
			    int max = 0;
			
			    unsafe
			    {
			    	Gl.glGetIntegerv(Gl.GL_MAX_RENDERBUFFER_SIZE_EXT, new IntPtr(&max));
			    }
			    
				return max;				
			}
		}
		
		#endregion
	}
}

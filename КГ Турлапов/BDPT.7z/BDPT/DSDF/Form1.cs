﻿using System;
using System.Windows.Forms;
using Auxiliary.VectorMath;
using Tao.OpenGl;

namespace DSDF
{
    public partial class Form1 : Form
    {
        private float[] _image; //изображение 
        private Render _render;
        private Scene _scene;
        private int _iterCount; //количество выполненных итераций

        private void InitializeRoom(ref Scene scene, float mirrorReflection, float lightParam)
        {
            Gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
            Gl.glViewport(0, 0, 512, 512);

            

            //нижняя стенка
            _scene.Objects.Add(new PlainSell(new Vector3D(0, 1, 0),
                                            new Vector3D(0, -1, -512),
                                            new Vector3D(512, 1, 0),
                                            0,
                                            new BSDF(new Vector3D(1, 0, 0), new Vector3D(0, 0, 0), new Vector3D(0, 0, 0))));

            //верхняя стенка
            _scene.Objects.Add(new Plane(new Vector3D(0, -1, 0),
                                        new Vector3D(0, 511, -512),
                                        new Vector3D(512, 513, 0),
                                        -512,
                                        new BSDF(new Vector3D(0.6f, 0.6f, 0.6f),
                                                 new Vector3D(0, 0, 0),
                                                 new Vector3D(0, 0, 0))));

            //левая стенка
            _scene.Objects.Add(new Plane(new Vector3D(1, 0, 0),
                                        new Vector3D(-1, 0, -512),
                                        new Vector3D(1, 512, 0),
                                        0,
                                        new BSDF(new Vector3D(0.6f, 0, 0), new Vector3D(0, 0, 0), new Vector3D(0, 0, 0))));

            //правая стенка
            _scene.Objects.Add(new Plane(new Vector3D(-1, 0, 0),
                                        new Vector3D(511, 0, -512),
                                        new Vector3D(513, 512, 0),
                                        -512,
                                        new BSDF(new Vector3D(0, 0.6f, 0),
                                                 new Vector3D(mirrorReflection, mirrorReflection, mirrorReflection),
                                                 new Vector3D(0, 0, 0))));


            //задняя стенка
            _scene.Objects.Add(new Plane(new Vector3D(0, 0, 1),
                                        new Vector3D(0, 0, -513),
                                        new Vector3D(512, 512, -511),
                                        -512,
                                        new BSDF(new Vector3D(0, 0.1f, 0.8f),
                                                 new Vector3D(0, 0, 0),
                                                 new Vector3D(0, 0, 0))));

            ////зеркальная сфера
            _scene.Objects.Add(new Sphere(new Vector3D(400, 200, -300),
                                         100,
                                         new BSDF(new Vector3D(0, 0, 0), new Vector3D(1, 1, 1), new Vector3D(0, 0, 0))));

            //диффузная сфера
            _scene.Objects.Add(new Sphere(new Vector3D(400, 400, -360),
                                         40,
                                         new BSDF(new Vector3D(1, 1, 1), new Vector3D(0, 0, 0), new Vector3D(0, 0, 0))));

            //тэтраэдр 1
            _scene.Objects.Add(new Tetraedr(new Vector3D(0 + 100 + 20, 0 + 100, 0 - 50),
                                            new Vector3D(100 + 100 + 20, 100 + 100, 100 - 50),
                                            new Vector3D(-100 + 100 + 20, 100 + 100, 100 - 50),
                                            new Vector3D(100 + 100 + 20, 100 + 100, -100 - 50),
                                            new BSDF(new Vector3D(0, 0, 0), new Vector3D(0, 0, 0), new Vector3D(1, 1, 1))));
            //тэтраэдр 2
            _scene.Objects.Add(new Tetraedr(new Vector3D(0 + 100 + 20, 200 + 100, 0 - 50),
                                           new Vector3D(100 + 100 + 20, 100 + 100, 100 - 50),
                                           new Vector3D(-100 + 100 + 20, 100 + 100, 100 - 50),
                                           new Vector3D(100 + 100 + 20, 100 + 100, -100 - 50),
                                           new BSDF(new Vector3D(0, 0, 0), new Vector3D(0, 0, 0), new Vector3D(1, 1, 1))));

            //источник света
            _scene.Light = new Source(new Vector3D(lightParam, lightParam, lightParam), new Vector3D(256, 511, -256), 200, 200);
        }

        public Form1()
        {
            InitializeComponent();

            mainOpenGlControl.InitializeContexts();

            _scene = new Scene();
            InitializeRoom(ref _scene, 0f, 1f);
            _image = new float[512 * 512 * 3];
            _render = new Render(_scene);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int countIters = Convert.ToInt32(textBox1.Text);
            float mirrorReflection = 0.1f * Convert.ToInt32(trackBarMirror.Value);
            float lightParam = 0.1f * Convert.ToInt32(trackBarLight.Value);
            _iterCount = 0;

            button1.Enabled = false;
            textBox1.Enabled = false;
            progressBar1.Maximum = countIters;
            progressBar1.Value = 0;


            _scene = new Scene();
            //_scene.Light.Material.Emission = new Vector3D(lightParam, lightParam, lightParam);
            InitializeRoom(ref _scene, mirrorReflection, lightParam);
            _image = new float[512 * 512 * 3];
            _render = new Render(_scene);

            
            
            

            for (int i = 0; i < countIters; i++)
            {
                _render.FillImage(_image, _iterCount, lightParam);
                Gl.glDrawPixels(512, 512, Gl.GL_RGB, Gl.GL_FLOAT, _image);
                mainOpenGlControl.Invalidate();
                _iterCount++;
                ++progressBar1.Value;
                progressBar1.Update();
            }

            button1.Enabled = true;
            textBox1.Enabled = true;
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }
    }
}
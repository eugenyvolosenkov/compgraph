﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Auxiliary.VectorMath;

namespace DSDF
{
    public class Render
    {

        private int max_depth = 10;
        private Scene scene;
        Vector3D eye = new Vector3D(256,256,1228);
        
        public Render(Scene scene)
        {
            this.scene = scene;
        }
        
        public Vector3D PathTrace(Ray ray, int depth)
        {
            if (depth == max_depth) return new Vector3D(0,0,0);
            Hit hit = scene.hit(ray);
            if (hit.Distance < 10000&&hit.Distance>0)
            {
                //было пересечение 
                BSDF dsdf = hit.Material;
                return dsdf.Kd;
            }
            else
            {
                return Vector3D.Zero;
            }
        }

        public void FillImage(float[] image)
        {
            for (int i = 0; i < 512; i++)
	        {
                for (int j = 0; j < 512; j++)
		        {

                    Ray ray = new Ray();
                    ray.Origin = eye;


                    ray.Direct = new Vector3D(j + Global.GetRndFloat(), i + Global.GetRndFloat(), 0) - eye;

                    ray.Direct = Vector3D.Normalize(ray.Direct);

                    Vector3D color = PathTrace(ray,0);

                    image[(i*512+j)*3]    += color.X;
                    image[(i*512+j)*3 +1] += color.Y;
                    image[(i*512+j)*3 +2] += color.Z;
                }
            }
        }

       
    }
}

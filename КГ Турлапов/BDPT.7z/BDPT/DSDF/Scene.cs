﻿using System;
using System.Collections.Generic;
using Auxiliary.VectorMath;

namespace DSDF
{
    public static class Global
    {
        private static readonly Random Rnd = new Random();

        public static Vector3D UnitX = new Vector3D(1, 0, 0);
        public static Vector3D UnitY = new Vector3D(0, 1, 0);
        public static Vector3D UnitZ = new Vector3D(0, 0, 1);

        public static float GetRndFloat()
        {
            return (float) Rnd.NextDouble();
        }
    }

    public struct Ray
    {
        public Vector3D Direct;
        public Vector3D Origin;

        public Ray(Vector3D origin, Vector3D direct)
        {
            Origin = origin;
            Direct = direct;
        }

        public Vector3D at(float time)
        {
            return Origin + Direct * time;
        }

        public void move(float time)
        {
            Origin = at(time);
        }
    }

    public struct BSDF
    {
        public Vector3D Emission;
        public Vector3D Kd;
        public Vector3D Ks;
        public Vector3D Kt;

        public BSDF(Vector3D kd, Vector3D ks, Vector3D kt)
        {
            Kd = kd;
            Ks = ks;
            Kt = kt;
            Emission = Vector3D.Zero;
        }

        public BSDF(Vector3D emission)
        {
            Kd = Vector3D.Zero;
            Ks = Vector3D.Zero;
            Kt = Vector3D.Zero;
            Emission = emission;
        }

        private float max(Vector3D v)
        {
            //float max = Math.Max(v.X, v.Y);
            //max = Math.Max(max, v.Y);
            //return max;
            return Math.Max(v.X, v.Y);
        }

        public Vector3D sample(Vector3D output, Vector3D normal, Vector3D oldColor, ref Vector3D newColor)
        {
            Vector3D input;

            var ls = new LocalSpace(normal);
            float rnd = Global.GetRndFloat();

            float Pd = max(Kd);
            float Ps = max(Ks);
            float Pt = max(Kt);
            float sum = Pd + Ps + Pt;

            if (rnd <= Pd / sum)
            {
                //дифузное отражение
                float r1 = Global.GetRndFloat();
                float r2 = Global.GetRndFloat();
                input = ls.from(MapSampleToCosineDistribution(r1, r2));
                newColor = oldColor * Kd;
            }
            else if (rnd <= (Pd + Ps) / sum)
            {
                //зеркальное отражение
                input = Vector3D.Reflect(output, normal);
                newColor = oldColor * Ks;
            }
            else
            {
                input = Vector3D.Zero;
                if (!refract(output, normal, 1.51714f, ref input))
                {
                    input = Vector3D.Zero;
                }
                newColor = oldColor * Kt;
            }
            return input;
        }

        private float Convolve(Vector3D vector, Vector3D factor)
        {
            return Vector3D.Dot(vector, factor) / (factor.X + factor.Y + factor.Z);
        }

        // переход к сферическим координатам
        public Vector3D MapSampleToCosineDistribution(float r1, float r2)
        {
            var sin_phi = (float) Math.Sin(2 * r1 * Math.PI);
            var cos_phi = (float) Math.Cos(2 * r1 * Math.PI);
            ;

            var cos_theta = (float) Math.Pow(1 - r2, 0.5);
            var sin_theta = (float) Math.Sqrt(1 - cos_theta * cos_theta);

            float x = sin_theta * cos_phi;
            float y = sin_theta * sin_phi;
            float z = cos_theta;

            return new Vector3D(x, y, z);
        }

        private bool refract(Vector3D output, Vector3D normal, float eta, ref Vector3D input)
        {
            normal = Vector3D.Normalize(normal);
            eta = 1.0f / eta;
            float cos_theta = -Vector3D.Dot(normal, output);

            if (cos_theta < 0)
            {
                normal *= (-1);
                cos_theta *= -1.0f;
                eta = 1.0f / eta;
            }

            var k = (float) (1.0f - eta * eta * (1.0 - cos_theta * cos_theta));

            if (k > 0)
            {
                input = eta * output + (float) (eta * cos_theta - Math.Sqrt(k)) * normal;
                input = Vector3D.Normalize(input);
                return true;
            }
            return false;
        }
    };

    public struct LocalSpace
    {
        public Vector3D AxisX;
        public Vector3D AxisY;
        public Vector3D AxisZ;

        public LocalSpace(Vector3D axisX, Vector3D axisY, Vector3D axisZ)
        {
            AxisX = axisX;
            AxisY = axisY;
            AxisZ = axisZ;
        }

        public LocalSpace(Vector3D normal)
        {
            AxisZ = normal;

            AxisX = Vector3D.Cross(new Vector3D(0, 1, 0), normal);
            AxisY = Vector3D.Cross(new Vector3D(1, 0, 0), normal);

            float xLength = Vector3D.Length(AxisX), yLength = Vector3D.Length(AxisY);

            if (xLength > yLength)
            {
                AxisX = AxisX / xLength;
                AxisY = Vector3D.Cross(AxisX, normal);
            }
            else
            {
                AxisY = AxisY / yLength;
                AxisX = Vector3D.Cross(AxisY, normal);
            }
        }

        // в
        public Vector3D to(Vector3D vector)
        {
            return new Vector3D(Vector3D.Dot(vector, AxisX), Vector3D.Dot(vector, AxisY), Vector3D.Dot(vector, AxisZ));
        }

        // из
        public Vector3D from(Vector3D vector)
        {
            return vector.X * AxisX + vector.Y * AxisY + vector.Z * AxisZ;
        }
    };

    public abstract class Geometry
    {
        public BSDF Material;

        public Geometry(BSDF material)
        {
            Material = material;
        }

        public abstract float hit(Ray ray);

        public abstract void setColor(Vector3D point);

        public abstract Vector3D normal(Vector3D point);
    };

    public class Sphere : Geometry
    {
        public Vector3D Center;
        public float Radius;

        public Sphere(Vector3D center, float radius, BSDF material)
            : base(material)
        {
            Center = center;
            Radius = radius;
        }

        public override float hit(Ray ray)
        {
            Vector3D origin = ray.Origin - Center, direct = ray.Direct;

            double A = Vector3D.Dot(direct, direct), B = Vector3D.Dot(direct, origin), C = Vector3D.Dot(origin, origin);

            double D = B * B - A * (C - Radius * Radius);

            if (D > 0)
            {
                D = Math.Sqrt(D);

                C = (-B - D) / A;
                D = (-B + D) / A;

                if (D >= 0)
                {
                    return C >= 0 ? (float) C : (float) D;
                }
            }

            return -1;
        }

        public override Vector3D normal(Vector3D point)
        {
            return Vector3D.Normalize(point - Center);
        }

        public override void setColor(Vector3D point)
        {
        }
    }

    public class PlainSell : Plane
    {
        public PlainSell(Vector3D normal, Vector3D minimum, Vector3D maximum, float translation, BSDF material)
            : base(normal, minimum, maximum, translation, material)
        {
        }

        public override void setColor(Vector3D point)
        {
            var sizeX = (int) (Maximum.X - Minimum.X);
            var sizeZ = (int) (Maximum.Z - Minimum.Z);

            var X = (int) point.X;
            var Z = (int) point.Z;

            int sizeSellX = sizeX / 8;
            int sizeSellZ = sizeZ / 8;

            if ((X / sizeSellX) % 2 == 0 && (Z / sizeSellZ) % 2 == 0 ||
                (X / sizeSellX) % 2 != 0 && (Z / sizeSellZ) % 2 != 0)
            {
                Material.Kd = new Vector3D(0, 0, 1);
            }
            else
            {
                Material.Kd = new Vector3D(1, 1, 1);
            }
        }
    }

    public class Plane : Geometry
    {
        public Vector3D Maximum;
        public Vector3D Minimum;
        public Vector3D Normal;
        public float Translation;

        public Plane(Vector3D normal, Vector3D minimum, Vector3D maximum, float translation, BSDF material)
            : base(material)
        {
            Normal = normal;
            Minimum = minimum;
            Maximum = maximum;
            Translation = translation;
        }

        public override float hit(Ray ray)
        {
            float time = (Translation - Vector3D.Dot(Normal, ray.Origin)) / Vector3D.Dot(Normal, ray.Direct);

            Vector3D point = ray.at(time);

            bool outside = (point.X < Minimum.X - 1E-5 || point.X > Maximum.X + 1E-5) ||
                           (point.Y < Minimum.Y - 1E-5 || point.Y > Maximum.Y + 1E-5) ||
                           (point.Z < Minimum.Z - 1E-5 || point.Z > Maximum.Z + 1E-5);

            return outside ? -1 : time;
        }

        public override Vector3D normal(Vector3D point)
        {
            return Normal;
        }

        public override void setColor(Vector3D point)
        {
        }
    }

    public struct Hit
    {
        public float Distance;
        public BSDF Material;
        public Vector3D Normal;
        public Vector3D Point;

        public Hit(float distance)
        {
            Distance = distance;
            Material = new BSDF();
            Normal = null;
            Point = null;
        }

        public Hit(BSDF material, float distance)
        {
            Material = material;
            Distance = distance;
            Normal = null;
            Point = null;
        }
    }

    public class Scene
    {
        public Source Light;
        public List<Geometry> Objects = new List<Geometry>();

        public float visibility(Ray ray, float time)
        {
            if (time <= 0)
            {
                return 1.0f; // слишком маленькое расстояние
            }

            for (int i = 0; i < Objects.Count; ++i)
            {
                float test = Objects[i].hit(ray);

                if (test > 0 && test < time)
                {
                    return 0.0f;
                }
            }

            float test1 = Light.intersect(ray);

            if (test1 >= 0)
            {
                if (test1 < time)
                {
                    return 0.0f;
                }
            }

            return 1.0f;
        }

        public Hit hit(Ray ray)
        {
            float test;

            var hit = new Hit(1000000);

            Geometry obj = null;

            for (int i = 0; i < Objects.Count; ++i)
            {
                test = Objects[i].hit(ray);

                if (test > 0 && test < hit.Distance)
                {
                    obj = Objects[i];
                    obj.setColor(ray.at(test));
                    hit = new Hit(obj.Material, test);
                }
            }

            if (ReferenceEquals(obj, null))
            {
                hit.Distance = -1;
            }
            else
            {
                hit.Point = ray.at(hit.Distance);

                hit.Normal = obj.normal(hit.Point);
            }

            test = Light.intersect(ray);
            if (test >= 0)
            {
                if (hit.Distance < 0 || test < hit.Distance)
                {
                    hit = new Hit(Light.Material, test);
                }

                hit.Point = ray.at(hit.Distance);

                hit.Normal = Light.normal();
            }

            return hit;
        }
    }

    public struct Source
    {
        private readonly Vector3D Normal;
        public Vector3D Center;
        public BSDF Material;

        public float SizeX;

        public float SizeZ;

        public Source(Vector3D radiance, Vector3D center, float sizeX, float sizeZ)
        {
            Normal = new Vector3D(0, -1, 0);
            Center = center;
            SizeX = sizeX;
            SizeZ = sizeZ;
            Material = new BSDF(radiance);
        }

        public Vector3D normal()
        {
            return Normal;
        }

        public void sample(Vector3D point)
        {
            float ksi1 = Global.GetRndFloat() - 0.5f, ksi2 = Global.GetRndFloat() - 0.5f;

            point = Center + SizeX * new Vector3D(1, 0, 0) * ksi1 + SizeZ * new Vector3D(0, 0, 1) * ksi2;
        }

        public float intersect(Ray ray, Vector3D radiance = null)
        {
            float distance;
            Vector3D origin = ray.Origin - Center, direct = ray.Direct;
            origin = new Vector3D(Vector3D.Dot(Global.UnitX, origin),
                                  Vector3D.Dot(Normal, origin),
                                  Vector3D.Dot(Global.UnitZ, origin));
            direct = new Vector3D(Vector3D.Dot(Global.UnitX, direct),
                                  Vector3D.Dot(Normal, direct),
                                  Vector3D.Dot(Global.UnitZ, direct));
            distance = -origin.Y / direct.Y;

            bool outside = Math.Abs(origin.X + direct.X * distance) > SizeX / 2.0f ||
                           Math.Abs(origin.Z + direct.Z * distance) > SizeZ / 2.0f;

            if (!ReferenceEquals(radiance, null))
            {
                radiance = Vector3D.Dot(Normal, ray.Direct) < 0 ? Material.Emission : Vector3D.Zero;
            }
            if (outside)
            {
                distance = -1;
            }
            return distance;
        }
    };

    public class Tetraedr : Geometry
    {
        private readonly Vector3D[] points = new Vector3D[4];

        public Tetraedr(Vector3D p1, Vector3D p2, Vector3D p3, Vector3D p4, BSDF mat)
            : base(mat)
        {
            points[0] = p1;
            points[1] = p2;
            points[2] = p3;
            points[3] = p4;
        }

        private void getTriangleAndPoint(int numberOfPoint, ref Vector3D[] array, ref Vector3D point)
        {
            point = points[numberOfPoint];
            int k = 0;
            for (int i = 0; i < 4; i++)
            {
                if (i == numberOfPoint)
                {
                    continue;
                }
                array[k++] = points[i];
            }
        }

        public static bool trianglePlaneHasPoint(Vector3D a, Vector3D b, Vector3D c, Vector3D point)
        {
            Vector3D normal = Vector3D.Cross(a - b, c - b);
            float scalarMult = Vector3D.Dot(normal, point - b);
            bool result = Math.Abs(scalarMult) < 0.00001;
            return result;
        }

        public override Vector3D normal(Vector3D point)
        {
            var triangle = new Vector3D[3];
            Vector3D outPoint = null;

            for (int i = 0; i < 4; i++)
            {
                getTriangleAndPoint(i, ref triangle, ref outPoint);
                if (trianglePlaneHasPoint(triangle[0], triangle[1], triangle[2], point))
                {
                    break;
                }
            }

            Vector3D normal = Vector3D.Cross(triangle[0] - triangle[1], triangle[2] - triangle[1]);
            float scalarMult = Vector3D.Dot(normal, point - triangle[1]);

            normal = Vector3D.Normalize(normal);
            if (scalarMult < 0)
            {
                return normal;
            }
            return normal * (-1);
        }

        public override float hit(Ray ray)
        {
            float maxDistance = 1000000;
            float distance = maxDistance;
            var triangle = new Vector3D[3];
            Vector3D outPoint = null;

            for (int i = 0; i < 4; i++)
            {
                getTriangleAndPoint(i, ref triangle, ref outPoint);
                Vector3D TUY = Vector3D.Zero;
                float curDistance = maxDistance;
                if (intersect_triangle(ray, triangle[0], triangle[1], triangle[2], ref TUY) == 1)
                {
                    curDistance = TUY.X;
                    //нашли перечесение  
                    if (curDistance < distance)
                    {
                        distance = curDistance;
                    }
                }
            }

            if (distance == maxDistance)
            {
                return -1;
            }
            return distance;
        }

        public override void setColor(Vector3D point)
        {
        }

        private int intersect_triangle(Ray ray, Vector3D vert0, Vector3D vert1, Vector3D vert2, ref Vector3D TUV)
        {
            Vector3D edge1 = Vector3D.Zero;
            Vector3D edge2 = Vector3D.Zero;
            Vector3D tvec = Vector3D.Zero;
            Vector3D pvec = Vector3D.Zero;
            Vector3D qvec = Vector3D.Zero;

            float det, inv_det;

            edge1 = vert1 - vert0;
            edge2 = vert2 - vert0;

            pvec = Vector3D.Cross(ray.Direct, edge2);
            det = Vector3D.Dot(edge1, pvec);

            if (det > -0.0000001 && det < 0.0000001)
            {
                return 0;
            }

            inv_det = 1.0f / det;
            tvec = ray.Origin - vert0;
            TUV.Y = Vector3D.Dot(tvec, pvec) * inv_det;

            if (TUV.Y < 0.0 || TUV.Y > 1.0)
            {
                return 0;
            }

            qvec = Vector3D.Cross(tvec, edge1);

            TUV.Z = Vector3D.Dot(ray.Direct, qvec) * inv_det;
            if (TUV.Z < 0.0 || TUV.Y + TUV.Z > 1.0)
            {
                return 0;
            }

            TUV.X = Vector3D.Dot(edge2, qvec) * inv_det;

            return 1;
        }
    }

    //public class Cube : Geometry
    //{
    //    private Vector3D Size = new Vector3D(1, 1, 1);
    //    public Cube(BSDF mat)
    //        : base(mat)
    //    {

    //    }

    //    public override float hit(Ray ray)
    //    {
    //       Vector3D origin = Transform.InversePosition(ray.Origin);

    //        Vector3D direction = Transform.InverseDirection(ray.Direction);

    //        float [] candidates = new float[] { -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f };

    //        int index = 0;

    //        if (direction.X != 0.0f)
    //        {
    //            candidates[index++] = (-Size.X - origin.X) / direction.X;
    //            candidates[index++] = (Size.X - origin.X) / direction.X;
    //        }

    //        if (direction.Y != 0.0f)
    //        {
    //            candidates[index++] = (-Size.Y - origin.Y) / direction.Y;
    //            candidates[index++] = (Size.Y - origin.Y) / direction.Y;
    //        }

    //        if (direction.Z != 0.0f)
    //        {
    //            candidates[index++] = (-Size.Z - origin.Z) / direction.Z;
    //            candidates[index++] = (Size.Z - origin.Z) / direction.Z;
    //        }

    //        float time = Single.PositiveInfinity;

    //        foreach (float candidate in candidates)
    //        {
    //            if (candidate > 0.0f)
    //            {
    //                Vector3D point = origin + candidate * direction;

    //                if (point > -Size - Vector3D.Epsilon && point < Size + Vector3D.Epsilon)
    //                {
    //                    if (candidate < time)
    //                        time = candidate;
    //                }
    //            }
    //        }

    //        if (Single.IsPositiveInfinity(time))
    //        {
    //            return IntersectInfo.None;
    //        }
    //        else
    //        {
    //            if (origin >= -Size && origin <= Size)
    //            {
    //                return new IntersectInfo(time, IntersectType.Inner);
    //            }
    //            else
    //            {
    //                return new IntersectInfo(time, IntersectType.Outer);
    //            }
    //        }
    //    }
    //    public override void setColor(Vector3D position)
    //    {
    //        /* Vector3D color = Material.Kd;

    //         if (null != Material.Texture)
    //         {
    //             Vector3D local = Transform.InversePosition(position);

    //             if (Math.Abs(Math.Abs(local.X) - Size.X) < Util.Epsilon)
    //                 color *= Material.Texture.CalcColor((local / Size).YZ);
    //             else
    //                 if (Math.Abs(Math.Abs(local.Y) - Size.Y) < Util.Epsilon)
    //                     color *= Material.Texture.CalcColor((local / Size).XZ);
    //                 else
    //                     if (Math.Abs(Math.Abs(local.Z) - Size.Z) < Util.Epsilon)
    //                         color *= Material.Texture.CalcColor((local / Size).XY);

    //          }

    //         return color;*/
    //    }
    //    public override Vector3D CalcNormal(Vector3D position)
    //    {
    //        Vector3D local = Transform.InversePosition(position);

    //        if (Math.Abs(local.X + Size.X) < Util.Epsilon)
    //            return Vector3D.Normalize(Transform.TransformNormal(-Vector3D.I));
    //        else
    //            if (Math.Abs(local.X - Size.X) < Util.Epsilon)
    //                return Vector3D.Normalize(Transform.TransformNormal(Vector3D.I));
    //            else
    //                if (Math.Abs(local.Y + Size.Y) < Util.Epsilon)
    //                    return Vector3D.Normalize(Transform.TransformNormal(-Vector3D.J));
    //                else
    //                    if (Math.Abs(local.Y - Size.Y) < Util.Epsilon)
    //                        return Vector3D.Normalize(Transform.TransformNormal(Vector3D.J));
    //                    else
    //                        if (Math.Abs(local.Z + Size.Z) < Util.Epsilon)
    //                            return Vector3D.Normalize(Transform.TransformNormal(-Vector3D.K));
    //                        else
    //                            if (Math.Abs(local.Z - Size.Z) < Util.Epsilon)
    //                                return Vector3D.Normalize(Transform.TransformNormal(Vector3D.K));

    //        return Vector3D.Zero;
    //    }
    //}
}
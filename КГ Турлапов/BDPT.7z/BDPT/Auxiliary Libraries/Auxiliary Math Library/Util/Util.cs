﻿using System;

namespace Auxiliary.VectorMath
{
    /// <summary> Вспомогательные функции. </summary>
    public class Util
    {
        public static float Clamp(float arg, float min, float max)
        {
            if (arg < min)
            {
                return min;
            }
            else
            {
                if (arg > max)
                {
                    return max;
                }
                else
                {
                    return arg;
                }
            }
        }

        public static float Step(float arg, float edge)
        {
            if (arg < edge)
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }

        public static float SmoothStep(float arg, float left, float right)
        {
            float result = Clamp((arg - left) / (right - left), 0, 1);

            return result * result * (3 - 2 * result);
        }
    }
}

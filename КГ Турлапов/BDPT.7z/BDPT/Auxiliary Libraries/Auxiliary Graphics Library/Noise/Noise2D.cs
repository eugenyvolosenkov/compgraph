using System;
using System.Drawing;
using Auxiliary.VectorMath;
using Tao.OpenGl;

namespace Auxiliary.Graphics
{
	public class Noise2D
	{
		#region Private Fields
		
		private static int size = 16;
	
		private Vector2D [,] gradients = new Vector2D[size, size];
		
		#endregion
		
		#region Private Methods

        private float Drop(float dist)
        {
            float val = (float)System.Math.Abs(dist);

            if (val < 1)
            {
                return 1 - 3 * val * val + 2 * val * val * val;
            }
            else
            {
                return 0;
            }
        }
	
	    private Vector2D Gradient(int i, int j)
	    {
	        i &= size - 1;
	        j &= size - 1;
	
	        return gradients[i, j];
	    }

        private Vector2D Omega(int i, int j, Vector2D point)
	    {
            return Gradient(i, j) * Drop(point.X) * Drop(point.Y);
        }
        
        private Vector2D Noise(Vector2D point)
        {
            int floorX = (int)Math.Floor(point.X);
            int floorY = (int)Math.Floor(point.Y);

            Vector2D sum = Vector2D.Zero;

            for (int i = floorX; i < floorX + 2; i++)
            {
                for (int j = floorY; j < floorY + 2; j++)
                {
                    sum += Omega(i, j, new Vector2D(point.X - i, point.Y - j));
                }
            }

            return sum;
        }	
        
	    #endregion
	    
	    #region Constructors
	    
	    public Noise2D()
	    {	
		    Random random = new Random();

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    gradients[i, j] = new Vector2D((float)(2 * random.NextDouble() - 1),
                	                              (float)(2 * random.NextDouble() - 1));
                }
            }    	
	    }
			    
	    #endregion
	    
	    #region Public Methods
	    
	    public Texture2D CreateNoiseTexture(int width, int height)
	    {
            byte [] pixels = new byte [width * height];

            float dx = size / (float)width;
            float dy = size / (float)height;

            int index = 0;

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    Vector2D point = new Vector2D(i * dx, j * dy);

                    Vector2D noise = Noise(point);

                    pixels[index++] = (byte)((noise.X + 1) * 255 / 2);
                }
            }
            
            Texture2D texture = new Texture2D(width, height, Gl.GL_ALPHA, Gl.GL_ALPHA8);

            unsafe
            {
                fixed (byte* pointer = pixels)
                {
                    texture.Create(new IntPtr(pointer));
                }
            }    
            
            pixels = null;
		    
		    GC.Collect();

            return texture;
	    }
	
	    #endregion
	}
}

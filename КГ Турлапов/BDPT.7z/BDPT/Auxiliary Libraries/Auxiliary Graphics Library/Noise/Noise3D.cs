using System;
using System.Drawing;
using Auxiliary.VectorMath;
using Tao.OpenGl;

namespace Auxiliary.Graphics
{
	public class Noise3D
	{
		#region Private Fields
		
		private static int size = 8;
	
		private Vector3D [,,] gradients = new Vector3D[size, size, size];
		
		#endregion
		
		#region Private Methods

        private float Drop(float dist)
        {
            float val = (float)System.Math.Abs(dist);

            if (val < 1)
            {
                return 1 - 3 * val * val + 2 * val * val * val;
            }
            else
            {
                return 0;
            }
        }
	
	    private Vector3D Gradient(int i, int j, int k)
	    {
	        i &= size - 1;
	        j &= size - 1;
	        k &= size - 1;
	
	        return gradients[i, j, k];
	    }

        private Vector3D Omega(int i, int j, int k, Vector3D point)
	    {
            return Gradient(i, j, k) * Drop(point.X) * Drop(point.Y) * Drop(point.Z);
        }
        
        private Vector3D Noise(Vector3D point)
        {
            int floorX = (int)Math.Floor(point.X);
            int floorY = (int)Math.Floor(point.Y);
            int floorZ = (int)Math.Floor(point.Z);

            Vector3D sum = Vector3D.Zero;

            for (int i = floorX; i < floorX + 2; i++)
            {
                for (int j = floorY; j < floorY + 2; j++)
                {
	                for (int k = floorZ; k < floorZ + 2; k++)
	                {
	                    sum += Omega(i, j, k, new Vector3D(point.X - i, point.Y - j, point.Z - k));
	                }
                }
            }

            return sum;
        }	
        
	    #endregion
	    
	    #region Constructors
	    
	    public Noise3D()
	    {	
		    Random random = new Random();

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
	                for (int k = 0; k < size; k++)
	                {
	                    gradients[i, j, k] = new Vector3D((float)(2 * random.NextDouble() - 1),
	                	                                 (float)(2 * random.NextDouble() - 1),
	                	                                 (float)(2 * random.NextDouble() - 1));
	                }
                }
            }    	
	    }
			    
	    #endregion
	    
	    #region Public Methods
	    
	    public Texture3D CreateNoiseTexture(int width, int height, int depth)
	    {
            byte [] pixels = new byte [width * height * depth];

            float dx = size / (float)width;
            float dy = size / (float)height;
            float dz = size / (float)depth;

            int index = 0;

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
	                for (int k = 0; k < depth; k++)
	                {
	                    Vector3D point = new Vector3D(i * dx, j * dy, k * dz);
	
	                    Vector3D noise = Noise(point);
	
	                    pixels[index++] = (byte)((noise.X + 1) * 255 / 2);
	                }
                }
            }
            
            Texture3D texture = new Texture3D(width, height, depth, Gl.GL_ALPHA, Gl.GL_ALPHA8);

            unsafe
            {
                fixed (byte* pointer = pixels)
                {
                    texture.Create(new IntPtr(pointer));
                }
            }
            
            pixels = null;
		    
		    GC.Collect();

            return texture;
	    }
	
	    #endregion
	}
}

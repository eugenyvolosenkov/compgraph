using System;
using Tao.OpenGl;

namespace Auxiliary.Graphics
{
	public class Texture3D
	{
		#region Private Fields
			
		private int handle;
				
		#endregion
		
		#region Public Fields
		
		public int Width;
		
		public int Height;
		
		public int Depth;
				
		public int Format = Gl.GL_RGB;
		
		public int InternalFormat = Gl.GL_RGB8;
		
		public static readonly int Target = Gl.GL_TEXTURE_3D;
		
		#endregion
	
		#region Constructors
		
		public Texture3D(int width, int height, int depth)
		{
			Width = width;
			Height = height;
			Depth = depth;
			
		    unsafe
		    {
		    	fixed (int* pointer = &handle)
		    	{
		    		Gl.glGenTextures(1, new IntPtr(pointer));
		    	}
		    }
		}
		
		public Texture3D(int width, int height, int depth, int format, int internalFormat)
			: this(width, height, depth)
		{
			Format = format;
			InternalFormat = internalFormat;
		}
			
		#endregion
		
		#region Public Methods
	
		public void Create(IntPtr pixels)
		{				
			Gl.glBindTexture(Target, handle);
		    	
			Gl.glTexParameteri(Target, Gl.GL_TEXTURE_MAG_FILTER, Gl.GL_LINEAR);
			Gl.glTexParameteri(Target, Gl.GL_TEXTURE_MIN_FILTER, Gl.GL_LINEAR);
		
		    Gl.glTexParameteri(Target, Gl.GL_TEXTURE_WRAP_S, Gl.GL_REPEAT);
		    Gl.glTexParameteri(Target, Gl.GL_TEXTURE_WRAP_T, Gl.GL_REPEAT);
		    Gl.glTexParameteri(Target, Gl.GL_TEXTURE_WRAP_R, Gl.GL_REPEAT);
		    
		    Gl.glPixelStorei(Gl.GL_UNPACK_ALIGNMENT, 1);
		    
		    Gl.glTexImage3D(Target, 0, InternalFormat, Width, Height, Depth, 0, Format,
			                Gl.GL_UNSIGNED_BYTE, pixels);
		}
		
		public unsafe void Create()
		{	
			Create(new IntPtr());
		}
			
		public void Destroy()
		{
		    unsafe
		    {
		    	fixed (int* pointer = &handle)
		    	{
		    		Gl.glDeleteTextures(1, new IntPtr(pointer));
		    	}
		    }
		}
		
		#endregion
		
		#region Properties
				
		public int Handle
		{
			get
			{
				return handle;
			}
		}
		
		#endregion
	}
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Tao.OpenGl;
using Tao.Platform.Windows;
using Auxiliary.VectorMath;

namespace DSDF
{
    public partial class Form1 : Form
    {
        Scene MyScene;
        Render MyRender;
        float[] MyImage;

        public Form1()
        {
            InitializeComponent();

            simpleOpenGlControl1.InitializeContexts();

            // Устанавливаем цвет фона
            Gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

            // Устанавливаем размеры окна
            Gl.glViewport(0, 0, 512, 512);

            MyScene = new Scene();

            MyScene.Objects.Add(new Plane(
                    new Vector3D(0, 1, 0),

                    new Vector3D(0, -1, -512),
                    new Vector3D(512, 1, 0),
                    0,
                    new BSDF(
                        new Vector3D(1, 0, 0),
                        new Vector3D(0, 0, 0),
                        new Vector3D(0, 0, 0)
                        )
                    )
            );

            MyScene.Objects.Add(new Sphere(
                        new Vector3D(256, 256, -256),
                        100,
                        new BSDF(
                            new Vector3D(0, 1, 0),
                            new Vector3D(0, 0, 0),
                            new Vector3D(0, 0, 0)
                        )
                    )
                );

            MyScene.Light = new Source(new Vector3D(1,0,0),new Vector3D(260,500,-100),80,80);

            MyImage = new float[512 * 512 * 3];
            MyRender = new Render(MyScene);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            simpleOpenGlControl1.Invalidate();
            MyRender.FillImage(MyImage);
            Gl.glDrawPixels(512, 512, Gl.GL_RGB, Gl.GL_FLOAT, MyImage);
        }
    }
}
